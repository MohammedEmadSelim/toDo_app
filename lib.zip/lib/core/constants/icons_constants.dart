class IconsConstants {
  static const String visible = 'assets/Icons/eye-off.svg';
  static const String unVisible = 'assets/Icons/Eye.svg';
}
